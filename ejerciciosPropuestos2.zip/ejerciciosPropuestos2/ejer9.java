package ejerciciosPropuestos2;

public class ejer9 {
    public static void main(String[] args) {
        int num = 1;
        while(num < 101){
            int div = num % 2;
            if(div == 0){
                System.out.println(num);
            }
            else{
            }
            num = num + 1;
        }
    }
}

