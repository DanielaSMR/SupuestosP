package ejerciciosPropuestos2;

public class ejer10 {
    public static void main(String[] args) {
        int num = 1;
        while(num < 101){
            if(num%5 != 0){
                System.out.println(num);
            }else{
            }
            num = num + 1;
        }
    }
}
