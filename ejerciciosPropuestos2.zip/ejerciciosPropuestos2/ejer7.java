package ejerciciosPropuestos2;

import java.util.Scanner;

public class ejer7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Escribe un numero para pasarlo a numeros romano");
        int num = sc.nextInt();

        
    }
}
