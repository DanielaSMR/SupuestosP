package ejerciciosPropuestos2;
import java.util.*;
import java.util.stream.IntStream;
public class test {
    public static void main ( String [ ] args) {
        Random rnd = new Random();
        int valor = rnd.nextInt(100)+100;
        System.out.println(valor);
    }
}


