package ejerciciosPropuestos2;

public class ejer5 {
    public static void main(String[] args) {
        System.out.println("Tabla 1");
        System.out.println("*******");
        System.out.println("1 x 1 = " + 1*1 + "\n" + "1 x 2 = " + 1*2 + "\n" + "1 x 3 = " + 1*3 + "\n" + "1 x 3 = " + 1*3 + "\n" + "1 x 4 = " + 1*4 + "\n" + "1 x 5 = " + 1*5 + "\n" + "1 x 6 = " + 1*6 + "\n" + "1 x 7 = " + 1*7 + "\n" + "1 x 8 = " + 1*8 + "\n" + "1 x 9 = " + 1*9 + "\n" + "1 x 10 = " + 1*10 + "\n");
    }
}
