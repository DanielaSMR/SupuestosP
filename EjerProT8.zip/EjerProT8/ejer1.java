package EjerProT8;

import java.util.Scanner;

public class ejer1 {
    public static void main(String[] args) {
        Matriz matriz = new Matriz();
        matriz.solicitarTamanyos();
    }
}
