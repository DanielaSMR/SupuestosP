package EjerciciosAdicionales;

public class ejer3 {
    public static void main(String[] args) {
        int num = 1;
        while(num < 101){
            if(num%2 == 0 && num%3 == 0){
                System.out.println(num);
            }else{
            }
            num = num + 1;
        }
    }
}
